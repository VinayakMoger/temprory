package com.example.schoolerp.utils;

public class URLS {

    public static String BASE_URL = "https://www.netfits.in";
}
