package com.example.schoolerp;

public class VerifyOTPRequest {
    private int inputCode1;

    public int getInputCode1() {
        return inputCode1;
    }

    public void setInputCode1(int inputCode1) {
        this.inputCode1 = inputCode1;
    }

    private int inputCode2;

    public int getInputCode2() {
        return inputCode2;
    }

    public void setInputCode2(int inputCode2) {
        this.inputCode2 = inputCode2;
    }

    private int inputCode3;

    public int getInputCode3() {
        return inputCode3;
    }

    public void setInputCode3(int inputCode3) {
        this.inputCode3 = inputCode3;
    }

    private int inputCode4;

    public int getInputCode4() {
        return inputCode4;
    }

    public void setInputCode4(int inputCode4) {
        this.inputCode4 = inputCode4;
    }
}
