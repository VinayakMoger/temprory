package com.example.schoolerp;

import androidx.lifecycle.ViewModel;

public class Fragment1ViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}