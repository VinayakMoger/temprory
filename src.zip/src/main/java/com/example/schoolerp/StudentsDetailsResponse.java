package com.example.schoolerp;
import com.google.gson.annotations.SerializedName;
public class StudentsDetailsResponse {
    @SerializedName("studentId")
    private int studentId;

    @SerializedName("name")
    private String name;

    public String getName() {
        return null;
    }
}
