package com.example.schoolerp;

public class SendOTPRequest {

    private String mobile_number;

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }
}
